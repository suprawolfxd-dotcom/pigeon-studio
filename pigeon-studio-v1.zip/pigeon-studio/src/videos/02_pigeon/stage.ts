// Project Pigeon staging: who stands where, per shot. Pigeons and props live in set.tsx (they are not people).
import {TOTAL, shotAt, W} from '../../engine/core/clock';
import {autoGaze} from '../../engine/core/staging';
import {PersonP, seq} from '../../engine/chars/rig';
import type {CarP, MeterP, Things} from '../../engine/kits/downtown/street';
import type {CartP} from '../../engine/kits/grocery/store';
import {LX, YX, BX, Z0, NOSE_P} from './world';
export {TOTAL, shotAt};
export type Stage = {people: PersonP[]; carts: CartP[]; extra: string[]; cars: CarP[]; meters: MeterP[]; things: Things; clock: number; nStoryCars: number};
const NOSE_PT: [number, number, number] = [NOSE_P[0], 1.3, NOSE_P[2]];
export function stage(f: number): Stage {
  const s = shotAt(f), lf = s.lf, P: PersonP[] = [], Mt: MeterP[] = [];
  const GX = LX + 3.0;   // Skinner's spot at the lab bench
  switch (s.name) {
    case 'hook': P.push({who: 'goldman', p: [GX, 0, Z0 + 0.2], act: 'present', expr: 'proud', gaze: NOSE_PT}); break;
    case 'yard': P.push({who: 'goldman', p: [YX - 0.6, 0, Z0 + 0.3], ...seq(lf, [[0, 'think', 'neutral'], [Math.max(1, W('yard', 'hit') - 3), 'eureka', 'surprised']]), gaze: [YX + 1.2, 0.3, 8.0]}); break;
    case 'eyes': P.push({who: 'goldman', p: [YX - 0.8, 0, Z0 + 0.3], act: 'think', expr: 'smirk', gaze: [YX + 1.2, 0.3, 8.0]}); break;
    case 'build': P.push({who: 'goldman', p: [GX, 0, Z0 - 0.4], act: 'present', expr: 'proud', gaze: NOSE_PT}); break;
    case 'peck': P.push({who: 'goldman', p: [GX, 0, Z0 - 0.4], act: 'talk', expr: 'happy', gaze: NOSE_PT}); break;
    case 'army': P.push({who: 'officer', p: [BX - 0.8, 0, Z0 + 0.2], act: 'bounce', expr: 'grin', gaze: 'cam'}, {who: 'banker', p: [BX + 0.8, 0, Z0 + 0.2], act: 'bounce', expr: 'smug', gaze: 'cam'}); break;
    case 'vote': P.push({who: 'goldman', p: [GX, 0, Z0 - 0.4], act: 'present', expr: 'proud', gaze: NOSE_PT}); break;
    case 'tests': P.push({who: 'goldman', p: [GX, 0, Z0 - 0.4], act: 'cheer', expr: 'happy', gaze: NOSE_PT}); break;
    case 'money': P.push({who: 'officer', p: [BX - 1.0, 0, Z0], act: 'cross', expr: 'angry'}, {who: 'banker', p: [BX + 1.0, 0, Z0], act: 'shrug', expr: 'tired'}); break;
    case 'navy': P.push({who: 'navy', p: [BX, 0, Z0 + 0.2], act: 'present', expr: 'proud', gaze: 'cam'}); break;
    case 'crack': P.push({who: 'goldman', p: [GX, 0, Z0 - 0.4], ...seq(lf, [[0, 'proud', 'proud'], [Math.max(1, W('crack', 'kept') - 4), 'wink', 'wink']]), gaze: NOSE_PT}); break;
    case 'museum': break;
  }
  autoGaze(P, Mt);
  return {people: P, carts: [], extra: [], cars: [], meters: Mt, things: {}, clock: 9, nStoryCars: 0};
}
