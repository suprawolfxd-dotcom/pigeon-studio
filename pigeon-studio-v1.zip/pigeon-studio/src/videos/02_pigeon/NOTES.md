# Project Pigeon, version 1 (rough on purpose)
Script: 12 beats, ~56 s (estimated voice timing: 180 words). Light: Full (REMOTION_LOOK=full).
Cast: goldman (Skinner), officer + banker (army brass), navy (Navy officer). NEW in the engine: banker, officer, navy looks (chars + chars_full), pigeon, nose cone, missile, backyard/lab/brass-room/museum sets (src/videos/02_pigeon/set.tsx).
NOT verified yet (my sandbox has no network): npm install, the gates (06_CHECKS), any render. The gates also run with empty SOLIDS, so they check little here.
Run (Mac): double-click render.command, pick 02_pigeon, light Full. Any OS: npm install; VIDEO=02_pigeon REMOTION_LOOK=full npm run still:full  (then preview:full).
Timing is estimated: record the voice, then generate timeline.ts with src/engine/tools/timeline.py.
