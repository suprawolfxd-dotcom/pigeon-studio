// Project Pigeon camera: one continuous take per beat, moves land on the narration word (03_CAMERA_GRAMMAR).
import {K, type Take, type Kick, type Whip, type Flash, type Props} from '../../engine/camera/takes_api';
import {T} from '../../engine/core/clock';
import {SHOT_REAL as R} from './timeline';
import {LX, YX, BX, MX, NOSE_P} from './world';
export const PROPS: Props = {
  nose: [[NOSE_P[0], 1.35, NOSE_P[2]], [0.55, 0.5, 0.45]],
  screen: [[LX + 1.65, 1.35, 6.0], [0.25, 0.25, 0.2]],
  pigeon0: [[LX + 1.28, 1.2, 6.0], [0.25, 0.25, 0.2]],
  missile: [[LX - 2.3, 1.15, 6.1], [0.9, 0.35, 0.35]],
  row: [[LX + 0.2, 1.1, 6.0], [0.7, 0.3, 0.3]],
  vote1: [[LX + 0.2, 1.1, 6.0], [0.3, 0.3, 0.25]],
  yardbirds: [[YX + 1.3, 0.3, 8.0], [1.6, 0.3, 0.8]],
  pigeonY: [[YX + 0.8, 0.3, 7.8], [0.3, 0.3, 0.25]],
  pigeonY2: [[YX + 1.8, 0.3, 8.2], [0.3, 0.3, 0.25]],
  board: [[BX, 2.1, 5.5], [0.7, 0.35, 0.1]],
  coins: [[BX - 0.4, 0.95, 6.6], [0.4, 0.2, 0.3]],
  gbox: [[BX + 0.9, 1.1, 6.6], [0.4, 0.3, 0.25]],
  case: [[MX, 1.3, 7.0], [0.5, 0.45, 0.5]],
  hall: [[MX, 1.4, 7.0], [3.0, 1.4, 1.5]],
};
export const TAKES: Take[] = [
  {name: 'hook', why: 'pigeon in the nose cone, pull back to the missile + Skinner, push onto the cone on "target"', keys: [
    K(R.hook, 'prop:pigeon0', 'MCU', 0, 6, 38, {push: 1.1}),
    K(T('hook', 'missiles'), ['prop:missile', 'goldman'], 'WS', 0, 6, 42, {move: 'dolly', lead: 0.2, dur: 0.9}),
    K(T('hook', 'target'), 'prop:nose', 'MS', 8, 5, 38, {move: 'arc', lead: 0.25, dur: 0.8, push: 1.08})]},
  {name: 'yard', why: 'Skinner in the backyard, push to his face on "hit him"', keys: [
    K(R.yard, 'goldman', 'MS', -12, 4, 40, {push: 1.04}),
    K(T('yard', 'hit'), 'goldman', 'MCU', 10, 3, 38, {move: 'dolly', lead: 0.3, dur: 0.7, push: 1.1})]},
  {name: 'eyes', why: 'birds, then a sharp-eyed pigeon, then a calm one', keys: [
    K(R.eyes, ['goldman', 'prop:yardbirds'], 'FS', 10, 6, 42, {push: 1.03}),
    K(T('eyes', 'sharp'), 'prop:pigeonY', 'CU', 0, 3, 36, {move: 'dolly', lead: 0.2, dur: 0.7, push: 1.1}),
    K(T('eyes', 'panic'), 'prop:pigeonY2', 'MCU', -10, 4, 38, {move: 'arc', lead: 0.2, dur: 0.7})]},
  {name: 'build', why: 'Skinner + the nose cone, push to the screen on "screen"', keys: [
    K(R.build, ['goldman', 'prop:nose'], 'MS', 0, 6, 40, {push: 1.03}),
    K(T('build', 'screen'), 'prop:screen', 'CU', -10, 3, 36, {move: 'dolly', lead: 0.3, dur: 0.8, push: 1.1})]},
  {name: 'peck', why: 'pigeon, then the screen on "pecked", then the missile on "steered"', keys: [
    K(R.peck, 'prop:pigeon0', 'MCU', 0, 5, 38, {push: 1.05}),
    K(T('peck', 'pecked'), 'prop:screen', 'CU', -12, 3, 36, {move: 'arc', lead: 0.2, dur: 0.7}),
    K(T('peck', 'steered'), 'prop:missile', 'MS', -10, 6, 40, {move: 'dolly', lead: 0.2, dur: 0.8})]},
  {name: 'army', why: 'cut to the brass room, push onto the laughing officer', keys: [
    K(R.army, ['officer', 'banker'], 'MS', 0, 6, 42, {push: 1.05}),
    K(T('army', 'missile'), 'officer', 'MCU', 8, 4, 38, {move: 'dolly', lead: 0.2, dur: 0.7, push: 1.08})]},
  {name: 'vote', why: 'three pigeons in a row, the wrong one, then the row again', keys: [
    K(R.vote, 'prop:row', 'MS', 0, 8, 40, {push: 1.04}),
    K(T('vote', 'wrong'), 'prop:vote1', 'CU', 10, 5, 36, {move: 'arc', lead: 0.2, dur: 0.7}),
    K(T('vote', 'outvoted'), 'prop:row', 'MS', -6, 10, 40, {move: 'dolly', lead: 0.2, dur: 0.9})]},
  {name: 'tests', why: 'three quick push-ins: "worked. Again. And again."', keys: [
    K(R.tests, 'prop:screen', 'CU', 0, 3, 36, {push: 1.06}),
    K(T('tests', 'again', 1), 'prop:nose', 'MCU', 8, 4, 38, {move: 'dolly', lead: 0.15, dur: 0.5, push: 1.08}),
    K(T('tests', 'again', 2), 'prop:screen', 'CU', -8, 3, 36, {move: 'dolly', lead: 0.15, dur: 0.5, push: 1.1})]},
  {name: 'money', why: 'brass shake heads, the calendar says December 1943, the coins leave', keys: [
    K(R.money, ['officer', 'banker'], 'MS', 0, 5, 42, {push: 1.03}),
    K(T('money', 'december'), 'prop:board', 'CU', 0, 2, 36, {move: 'dolly', lead: 0.3, dur: 0.7, push: 1.05}),
    K(T('money', 'money'), 'prop:coins', 'MCU', -8, 18, 38, {move: 'arc', lead: 0.2, dur: 0.7})]},
  {name: 'navy', why: 'Navy officer, the guidance box, the board flips to 1953', keys: [
    K(R.navy, 'navy', 'MS', 0, 5, 40, {push: 1.03}),
    K(T('navy', 'electronic'), 'prop:gbox', 'MCU', -10, 6, 38, {move: 'dolly', lead: 0.25, dur: 0.8, push: 1.08}),
    K(T('navy', 'done'), 'prop:board', 'CU', 0, 2, 36, {move: 'dolly', lead: 0.2, dur: 0.7})]},
  {name: 'crack', why: 'Skinner proud, his kept pigeon, the screen again on "remembered"', keys: [
    K(R.crack, 'goldman', 'MCU', -8, 4, 38, {push: 1.05}),
    K(T('crack', 'kept'), 'prop:pigeon0', 'CU', 0, 4, 36, {move: 'dolly', lead: 0.25, dur: 0.8, push: 1.08}),
    K(T('crack', 'remembered'), 'prop:screen', 'CU', -10, 3, 36, {move: 'arc', lead: 0.2, dur: 0.7})]},
  {name: 'museum', why: 'the nose cone in its glass case, slow pull-back to the hall', keys: [
    K(R.museum, 'prop:case', 'MCU', 0, 6, 38, {push: 1.05}),
    K(T('museum', 'smithsonian'), 'prop:hall', 'WS', 0, 8, 42, {move: 'dolly', lead: 0.3, dur: 1.2})]},
];
export const KICKS: Kick[] = [];
export const WHIPS: Whip[] = [];
export const FLASHES: Flash[] = [];
