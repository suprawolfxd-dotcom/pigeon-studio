// Project Pigeon: no street, so no town solids. [x0, x1, y0, y1, z0, z1, name] boxes for the checkers; empty in v1 (the checks are weaker for it: see notes).
type Box = [number, number, number, number, number, number, string];
export const SOLIDS: Box[] = [];
export const LOGIC_SOLIDS: Box[] = [];
export const GATE_WAIVERS: {key: string; kind: string; why: string}[] = [];
