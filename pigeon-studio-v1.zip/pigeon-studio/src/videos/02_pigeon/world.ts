// Project Pigeon: where each room sits in the world (all inside x -40..40 so the sun-shadow box covers them).
export const LX = -30;   // lab
export const YX = -10;   // backyard
export const BX = 10;    // brass room
export const MX = 30;    // museum
export const Z0 = 8;     // people stand around z = 8
export const WALL = 5.4; // back wall of every room
export const BENCH_TOP = 0.9;
export const NOSE_P: [number, number, number] = [LX + 1.4, BENCH_TOP, 6.0];   // nose cone: ground point under the cone axis
export const YARD_BIRDS: {p: [number, number, number]; ry: number; seed: number; peck: boolean}[] = [
  {p: [YX + 0.2, 0, 7.9], ry: 0.9, seed: 1, peck: true}, {p: [YX + 0.8, 0, 7.8], ry: 1.4, seed: 2, peck: true},
  {p: [YX + 1.8, 0, 8.2], ry: -0.6, seed: 3, peck: false}, {p: [YX + 2.5, 0, 7.7], ry: 0.4, seed: 4, peck: true}, {p: [YX + 1.2, 0, 8.6], ry: 2.2, seed: 5, peck: true}];
