// Project Pigeon set (v1): four small rooms built from simple toon boxes + kit textures, plus the NEW pigeon, nose cone, missile.
// Only the room of the current shot is rendered. Same style as the kit: flat toon materials (ink outlines come from the post pass).
import React, {useMemo} from 'react';
import * as THREE from 'three';
import {lookToon} from '../../engine/look/look';
import type {Tod} from '../../engine/look/look';
import {drawSign, drawWood, drawTiles, drawWallpaper} from '../../engine/look/draw';
import {shotAt, ease, T, type V3} from '../../engine/core/clock';
import type {Stage} from './stage';
import {LX, YX, BX, MX, WALL, BENCH_TOP, NOSE_P, YARD_BIRDS} from './world';
export const AUDIO: {voice: string | null; bed: string | null} = {voice: null, bed: null};

const box = new THREE.BoxGeometry(1, 1, 1), sph = new THREE.SphereGeometry(1, 16, 12), cyl = new THREE.CylinderGeometry(0.5, 0.5, 1, 16);
const cone = new THREE.ConeGeometry(1, 1, 12), plane = new THREE.PlaneGeometry(1, 1), circ = new THREE.CircleGeometry(0.5, 32);
// nose cone shell: back half of an open cone, axis along +x after rotation (tip small, mouth wide), open toward the camera
const shellG = new THREE.CylinderGeometry(0.12, 0.45, 1.0, 28, 1, true, Math.PI / 2, Math.PI);

const drawScreen = () => {   // the little screen inside the nose cone: sea, a ship, the target rings
  const c = document.createElement('canvas'); c.width = c.height = 256; const g = c.getContext('2d')!;
  const sea = g.createLinearGradient(0, 0, 0, 256); sea.addColorStop(0, '#bfe3f2'); sea.addColorStop(0.45, '#e9f2f0'); sea.addColorStop(0.46, '#3f8a86'); sea.addColorStop(1, '#2a5f9a');
  g.fillStyle = sea; g.fillRect(0, 0, 256, 256);
  g.fillStyle = '#241726'; g.beginPath(); g.moveTo(70, 128); g.lineTo(186, 128); g.lineTo(168, 150); g.lineTo(88, 150); g.closePath(); g.fill();
  g.fillRect(108, 100, 26, 28); g.fillRect(140, 108, 18, 20); g.fillRect(116, 84, 8, 16);
  g.strokeStyle = '#d0532f'; g.lineWidth = 10; g.beginPath(); g.arc(128, 128, 70, 0, 7); g.stroke(); g.lineWidth = 6; g.beginPath(); g.arc(128, 128, 34, 0, 7); g.stroke();
  g.lineWidth = 4; g.beginPath(); g.moveTo(128, 40); g.lineTo(128, 216); g.moveTo(40, 128); g.lineTo(216, 128); g.stroke();
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
};

const toon = lookToon;
export const useSetData = () => useMemo(() => {
  const fw = drawWood('#a87a48', {planks: 5, seed: 8}); fw.repeat.set(4, 3);
  const ww = drawWood('#8a6a48', {planks: 6, vertical: true, seed: 17}); ww.repeat.set(4, 1);
  const tiles = drawTiles(); tiles.repeat.set(5, 4);
  const tilesM = drawTiles(); tilesM.repeat.set(5, 4);
  const wp = drawWallpaper(1.333); wp.repeat.set(6, 1);
  const sign = (l: string[], o: {bg?: string; fg?: string} = {}) => toon({map: drawSign(l, {w: 512, h: 256, ...o})});
  return {
    floorLab: toon({map: fw}), wallLab: toon({map: ww}), floorTile: toon({map: tiles}), floorMus: toon({map: tilesM}), wallpaper: toon({map: wp}),
    bench: toon({color: '#7a3b22'}), benchTop: toon({color: '#c89a5a'}), metal: toon({color: '#b9c1c9', side: THREE.DoubleSide}), metalDark: toon({color: '#6b7480'}),
    screen: new THREE.MeshBasicMaterial({map: drawScreen(), side: THREE.DoubleSide}),
    pigBody: toon({color: '#8a97a8'}), pigWing: toon({color: '#6f7d90'}), pigHead: toon({color: '#fdf9f6'}), beak: toon({color: '#f2992a'}), leg: toon({color: '#d0532f'}), ink: toon({color: '#1d1420'}),
    red: toon({color: '#c8432a'}), cream: toon({color: '#f4ead6'}),
    grass: toon({color: '#6fae5a'}), fence: toon({color: '#c8a468'}), trunk: toon({color: '#6b5240'}), leaf: toon({color: '#4f9a5a'}),
    table: toon({color: '#8a5a32'}), coin: toon({color: '#f2c23a'}), teal: toon({color: '#3f9a8c'}), pedestal: toon({color: '#efe0c0'}),
    glass: new THREE.MeshBasicMaterial({color: '#cfe8ff', transparent: true, opacity: 0.16, depthWrite: false}),
    sArmy: sign(['U.S. ARMY']), sDec: sign(['DEC 1943']), s48: sign(['1948'], {bg: '#d6e4ef'}), s53: sign(['1953'], {bg: '#d6e4ef'}),
    sPelican: sign(['PELICAN']), sMuseum: sign(['SKINNER', 'NOSE CONE']),
    pegboard: toon({color: '#6b5240'}), tool: toon({color: '#c9ccd1'}),
  };
}, []);
export type Mats = ReturnType<typeof useSetData>;

const B: React.FC<{g?: THREE.BufferGeometry; m: THREE.Material; p: V3; s: V3; r?: V3; sh?: boolean}> = ({g = box, m, p, s, r = [0, 0, 0], sh = true}) =>
  <mesh geometry={g} material={m} position={p} scale={s} rotation={r} castShadow={sh} receiveShadow={sh} />;

// ---------- NEW: the pigeon (grey body, paper-white ball head, dot eyes, orange beak, stick legs). Faces +z; peck = head dips forward ----------
const Pigeon: React.FC<{d: Mats; f: number; p: V3; ry: number; sc?: number; peck?: boolean; ph0?: number; seed?: number}> = ({d, f, p, ry, sc = 1.25, peck = false, ph0 = 0, seed = 0}) => {
  const per = 26, ph = (((f + ph0 + seed * 7) % per) + per) % per / per;
  const pk = peck ? Math.pow(Math.max(0, Math.sin(ph * Math.PI * 2)), 3) : 0;
  const bob = peck ? 0 : 0.01 * Math.sin((f + seed * 11) / 9);
  return (
    <group position={p} rotation={[0, ry, 0]} scale={sc}>
      <B g={sph} m={d.pigBody} p={[0, 0.17 + bob, 0]} s={[0.14, 0.125, 0.21]} />
      <B g={sph} m={d.pigWing} p={[0.125, 0.18 + bob, -0.01]} s={[0.03, 0.09, 0.17]} /><B g={sph} m={d.pigWing} p={[-0.125, 0.18 + bob, -0.01]} s={[0.03, 0.09, 0.17]} />
      <B m={d.pigWing} p={[0, 0.17, -0.23]} s={[0.12, 0.025, 0.14]} r={[0.25, 0, 0]} />
      <B g={cyl} m={d.leg} p={[0.04, 0.05, 0.02]} s={[0.02, 0.1, 0.02]} /><B g={cyl} m={d.leg} p={[-0.04, 0.05, 0.02]} s={[0.02, 0.1, 0.02]} />
      <B m={d.leg} p={[0.04, 0.008, 0.045]} s={[0.05, 0.016, 0.08]} /><B m={d.leg} p={[-0.04, 0.008, 0.045]} s={[0.05, 0.016, 0.08]} />
      <group position={[0, 0.27 + bob, 0.1]} rotation={[pk * 0.9, 0, 0]}>
        <B g={sph} m={d.pigBody} p={[0, -0.03, -0.01]} s={[0.065, 0.075, 0.065]} />
        <B g={sph} m={d.pigHead} p={[0, 0.07, 0.04]} s={[0.085, 0.085, 0.085]} />
        <B g={sph} m={d.ink} p={[0.055, 0.09, 0.1]} s={[0.014, 0.014, 0.014]} sh={false} /><B g={sph} m={d.ink} p={[-0.055, 0.09, 0.1]} s={[0.014, 0.014, 0.014]} sh={false} />
        <B g={cone} m={d.beak} p={[0, 0.06, 0.15]} s={[0.026, 0.07, 0.026]} r={[Math.PI / 2, 0, 0]} />
      </group>
    </group>
  );
};

// ---------- NEW: the nose cone (open toward the camera so we see the pigeon and the screen). p = point on the bench under the cone axis ----------
const NoseCone: React.FC<{d: Mats; f: number; p: V3; sc?: number; pigeon?: boolean; peck?: boolean}> = ({d, f, p, sc = 1, pigeon = true, peck = false}) => (
  <group position={p} scale={sc}>
    <B g={shellG} m={d.metal} p={[0, 0.45, 0]} s={[1, 1, 1]} r={[0, 0, -Math.PI / 2]} />
    <B m={d.metalDark} p={[0.27, 0.12, 0]} s={[0.2, 0.24, 0.3]} />
    <mesh geometry={circ} material={d.screen} position={[0.25, 0.45, 0]} scale={[0.4, 0.4, 1]} rotation={[0, -Math.PI / 4, 0]} />
    {pigeon && <Pigeon d={d} f={f} p={[-0.12, 0.13, 0]} ry={Math.PI / 2} sc={1.0} peck={peck} />}
  </group>
);

// ---------- NEW: the missile (red body, cream band, round nose, fins) on two trestles. p = centre of the body ----------
const Missile: React.FC<{d: Mats; p: V3}> = ({d, p}) => (
  <group position={p}>
    <B g={cyl} m={d.red} p={[0, 0, 0]} s={[0.6, 1.6, 0.6]} r={[0, 0, Math.PI / 2]} />
    <B g={cyl} m={d.cream} p={[0.3, 0, 0]} s={[0.62, 0.15, 0.62]} r={[0, 0, Math.PI / 2]} />
    <B g={cone} m={d.red} p={[1.1, 0, 0]} s={[0.3, 0.6, 0.3]} r={[0, 0, -Math.PI / 2]} />
    <B m={d.metalDark} p={[-0.7, 0.4, 0]} s={[0.4, 0.45, 0.04]} /><B m={d.metalDark} p={[-0.7, 0, 0.4]} s={[0.4, 0.04, 0.45]} />
    <B m={d.bench} p={[-0.4, -0.725, 0]} s={[0.1, 0.85, 0.5]} /><B m={d.bench} p={[0.5, -0.725, 0]} s={[0.1, 0.85, 0.5]} />
  </group>
);

const Floor: React.FC<{m: THREE.Material; x: number}> = ({m, x}) => <mesh geometry={plane} material={m} position={[x, 0, 7.5]} scale={[14, 10, 1]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow />;

const Lab: React.FC<{d: Mats; f: number; n: string}> = ({d, f, n}) => {
  const cone1 = n !== 'vote';   // in the vote beat the pigeons stand on the bench in a row instead
  return (<group>
    <Floor m={d.floorLab} x={LX} />
    <B m={d.wallLab} p={[LX, 1.8, WALL]} s={[10, 3.6, 0.1]} />
    <B m={d.pegboard} p={[LX + 0.5, 1.9, WALL + 0.07]} s={[3, 1.2, 0.04]} sh={false} />
    {[-1.1, -0.5, 0.1, 0.7, 1.2].map((x, i) => <B key={i} m={d.tool} p={[LX + 0.5 + x, 1.9 + (i % 2) * 0.12, WALL + 0.1]} s={[0.06, 0.4, 0.04]} sh={false} />)}
    <B m={d.benchTop} p={[LX + 0.4, 0.86, 6.0]} s={[3.4, 0.08, 0.8]} /><B m={d.bench} p={[LX + 0.4, 0.56, 6.38]} s={[3.4, 0.6, 0.04]} />
    {[-1.6, 1.6].map((x, i) => <B key={i} m={d.bench} p={[LX + 0.4 + x, 0.43, 6.0]} s={[0.1, 0.86, 0.7]} />)}
    <B g={plane} m={d.sPelican} p={[LX + 1.4, 0.55, 6.41]} s={[0.7, 0.35, 1]} sh={false} />
    <NoseCone d={d} f={f} p={NOSE_P} pigeon={cone1 && n !== 'army'} peck={['hook', 'peck', 'tests', 'crack'].includes(n)} />
    <Missile d={d} p={[LX - 2.3, 1.15, 6.1]} />
    {n === 'vote' && [-0.25, 0.2, 0.65].map((x, i) => <Pigeon key={i} d={d} f={f} p={[LX + x, BENCH_TOP, 6.0]} ry={Math.PI / 2} sc={1.1} peck ph0={i === 1 ? 13 : 0} />)}
  </group>);
};

const Yard: React.FC<{d: Mats; f: number}> = ({d, f}) => (<group>
  <Floor m={d.grass} x={YX} />
  {Array.from({length: 26}, (_, i) => <B key={i} m={d.fence} p={[YX - 5 + i * 0.4, 0.75, WALL]} s={[0.3, 1.5, 0.06]} />)}
  <B m={d.fence} p={[YX, 0.5, WALL + 0.05]} s={[10.4, 0.1, 0.05]} /><B m={d.fence} p={[YX, 1.1, WALL + 0.05]} s={[10.4, 0.1, 0.05]} />
  <B g={cyl} m={d.trunk} p={[YX - 3.2, 1.1, 6.3]} s={[0.4, 2.2, 0.4]} /><B g={sph} m={d.leaf} p={[YX - 3.2, 3.0, 6.3]} s={[1.3, 1.3, 1.3]} />
  {YARD_BIRDS.map((b, i) => <Pigeon key={i} d={d} f={f} p={b.p} ry={b.ry} seed={b.seed} peck={b.peck} />)}
</group>);

const Brass: React.FC<{d: Mats; f: number; n: string}> = ({d, f, n}) => {
  const t = f / 30;
  const board = n === 'army' ? d.sArmy : n === 'money' ? d.sDec : t < T('navy', 'electronic') ? d.s48 : d.s53;
  const sweep = n === 'money' ? ease((t - T('money', 'money') - 0.3) / 0.9) : 0;
  return (<group>
    <Floor m={d.floorTile} x={BX} />
    <B m={d.wallpaper} p={[BX, 1.8, WALL]} s={[10, 3.6, 0.1]} />
    <B m={d.table} p={[BX, 2.1, WALL + 0.055]} s={[1.5, 0.8, 0.02]} sh={false} /><B g={plane} m={board} p={[BX, 2.1, WALL + 0.07]} s={[1.4, 0.7, 1]} sh={false} />
    <B m={d.table} p={[BX, 0.76, 6.6]} s={[3.0, 0.08, 1.0]} />
    {[-1.35, 1.35].flatMap((x) => [6.2, 7.0].map((z) => <B key={x + '_' + z} m={d.table} p={[BX + x, 0.36, z]} s={[0.08, 0.72, 0.08]} />))}
    {n === 'money' && <group position={[-sweep * 3.5, 0, 0]}>{[0, 1, 2, 3, 4, 5].map((i) => <B key={i} g={cyl} m={d.coin} p={[BX - 0.4 + (i % 2) * 0.3, 0.82 + Math.floor(i / 2) * 0.03, 6.6 + (i % 3 - 1) * 0.1]} s={[0.25, 0.03, 0.25]} />)}</group>}
    {n === 'navy' && <group position={[BX + 0.9, 0, 6.6]}>
      <B m={d.teal} p={[0, 1.05, 0]} s={[0.7, 0.5, 0.4]} />
      {[-0.22, 0, 0.22].map((x, i) => <B key={i} g={cyl} m={d.cream} p={[x, 1.05, 0.21]} s={[0.13, 0.04, 0.13]} r={[Math.PI / 2, 0, 0]} />)}
      <B g={cyl} m={d.metalDark} p={[0.25, 1.55, 0]} s={[0.02, 0.6, 0.02]} />
    </group>}
  </group>);
};

const Museum: React.FC<{d: Mats; f: number}> = ({d, f}) => (<group>
  <Floor m={d.floorMus} x={MX} />
  <B m={d.wallpaper} p={[MX, 1.8, WALL]} s={[10, 3.6, 0.1]} />
  <B m={d.pedestal} p={[MX, 0.45, 7.0]} s={[1.0, 0.9, 1.0]} />
  <B g={plane} m={d.sMuseum} p={[MX, 0.5, 7.51]} s={[0.7, 0.35, 1]} sh={false} />
  <NoseCone d={d} f={f} p={[MX, 0.9, 7.0]} sc={0.7} pigeon={false} />
  <B m={d.glass} p={[MX, 1.28, 7.0]} s={[0.9, 0.76, 0.9]} sh={false} />
</group>);

type P = {d: Mats; f: number; st: Stage; cam: THREE.Vector3; vel: (THREE.Vector3 | null)[]; tod: Tod};
export const SetBefore: React.FC<P> = ({d, f}) => {
  const n = shotAt(f).name;
  return (<>
    {['hook', 'build', 'peck', 'vote', 'tests', 'crack'].includes(n) && <Lab d={d} f={f} n={n} />}
    {(n === 'yard' || n === 'eyes') && <Yard d={d} f={f} />}
    {['army', 'money', 'navy'].includes(n) && <Brass d={d} f={f} n={n} />}
    {n === 'museum' && <Museum d={d} f={f} />}
  </>);
};
export const SetAfter: React.FC<P> = () => null;
